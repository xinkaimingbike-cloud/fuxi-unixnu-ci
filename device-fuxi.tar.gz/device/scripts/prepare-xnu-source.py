#!/usr/bin/env python3
"""Restore omitted DriverKit headers from Apple's earlier Darwin 23 source."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import urllib.parse
import urllib.request

# Tags of the Apple sources that still carry the headers newer xnu omits; feeds.toml sets them for the unixnu driver.
TAG = os.environ.get('UNIXNU_DRIVERKIT_TAG', 'xnu-10063.121.3')
TRUST_TAG = os.environ.get('UNIXNU_TRUSTCACHE_TAG', 'xnu-8796.101.5')
DESTINATION = Path('.cache/xnu-work/iokit/DriverKit')
CACHE = Path(f'.cache/sources/xnu-driverkit-{TAG.removeprefix("xnu-")}.json')
URL = f'https://api.github.com/repos/apple-oss-distributions/xnu/contents/iokit/DriverKit?ref={TAG}'
# Anonymous GitHub API calls share a small per-address quota that hosted CI runners exhaust (HTTP 403);
# a token in GITHUB_TOKEN or GH_TOKEN is sent to GitHub hosts only.
TOKEN = os.environ.get('GITHUB_TOKEN') or os.environ.get('GH_TOKEN')


def fetch(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'unixnu-prepare-xnu-source'})
    if TOKEN and urllib.parse.urlsplit(url).hostname in ('api.github.com', 'raw.githubusercontent.com'):
        request.add_header('Authorization', f'Bearer {TOKEN}')
    with urllib.request.urlopen(request, timeout=30) as response:
        return response.read()


def restore(entry, destination=DESTINATION, tag=TAG):
    if entry['type'] != 'file' or not entry['name'].endswith('.h'):
        return None
    name = entry.get('relative', entry['name'])
    target = destination / name
    if target.exists():
        return None
    data = fetch(entry['download_url'])
    digest = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if digest != entry['sha']:
        raise ValueError(f'Git blob hash mismatch: {entry["name"]}')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return {'name': name, 'source_tag': tag, 'git_blob': digest,
            'sha256': hashlib.sha256(data).hexdigest()}


def fix_duplicate_pmap_reserved():
    """Rename every repeated `reserved10` member so the patched pmap.h compiles.

    osfmk/arm/pmap/pmap.h declares `bool reserved10` more than once (the PAC and
    non-PAC copies of a later struct, plus copies a board patch reintroduces).
    The preprocessor keeps only one of each pair live, but clang rejects the
    struct before that choice is made, so every copy after the first becomes
    reserved13, reserved14, ... (names no code references).
    """
    path = Path('.cache/xnu-work/osfmk/arm/pmap/pmap.h')
    if not path.is_file():
        return None
    lines = path.read_text().splitlines(keepends=True)
    hits = [index for index, line in enumerate(lines) if 'bool reserved10;' in line]
    if len(hits) < 2:
        return None
    renamed = []
    for offset, index in enumerate(hits[1:], start=13):
        lines[index] = lines[index].replace('reserved10', f'reserved{offset}')
        renamed.append({'line': index + 1, 'member': f'reserved{offset}'})
    path.write_text(''.join(lines))
    return {'pmap_reserved_renamed': renamed}


def fix_mockfs_kalloc_type():
    """kalloc_type takes the struct type, not the typedef'd pointer.

    bsd/miscfs/mockfs/mockfs_fsnode.c passes mockfs_fsnode_t (already a pointer)
    where the newer kalloc_type() macro expects the struct itself, which trips the
    xnu_types static assertion on this compiler.
    """
    path = Path('.cache/xnu-work/bsd/miscfs/mockfs/mockfs_fsnode.c')
    if not path.is_file():
        return None
    source = path.read_text()
    if 'kalloc_type(struct mockfs_fsnode,' in source:
        return None
    replaced = source.replace('kalloc_type(mockfs_fsnode_t,', 'kalloc_type(struct mockfs_fsnode,')
    if replaced == source:
        return None
    path.write_text(replaced)
    return {'mockfs_kalloc_type': 'struct mockfs_fsnode'}


def fix_code_signature_entitlements():
    """bsd includes <CodeSignature/Entitlements.h>, a header only the Apple SDK ships.

    This source tree has no SDK: the Darwin sources carry EXTERNAL_HEADERS/
    CoreEntitlements instead, and the single symbol the network stack uses from
    that header is the browser-host entitlement name. Replace the include and the
    symbol with a literal so the entitlement lookup simply never matches, which is
    the unentitled answer this kernel wants anyway.
    """
    fixes = []
    for path in sorted(Path('.cache/xnu-work/bsd').rglob('*.[ch]')):
        source = path.read_text(errors='replace')
        if 'CodeSignature/' not in source and 'kCS' not in source:
            continue
        patched = source.replace(
            '#include <CodeSignature/Entitlements.h>',
            '/* No SDK CodeSignature headers here: browser entitlements are not needed. */')
        # The header also defines the entitlement-name constants, so every kCS*Entitlement
        # user becomes a literal that can never match an entitled task. Idempotent: an
        # already rewritten line no longer contains a kCS identifier.
        patched = re.sub(r'kCS[A-Za-z0-9_]*Entitlement', '""', patched)
        if patched != source:
            path.write_text(patched)
            fixes.append(str(path.relative_to('.cache/xnu-work')))
    return {'code_signature_entitlements': fixes} if fixes else None


def fix_stray_vm_user_indices():
    """mach_vm_deferred_reclamation_buffer_init() cancels a parameter it never had.

    The shipping osfmk/vm/vm_user.c ends the CONFIG_DEFERRED_RECLAIM == 0 branch
    with `(void) indices;`, but that function takes only task/address/size, so
    clang stops at "use of undeclared identifier 'indices'" and vm_user.o never
    builds. Drop the stray statement.
    """
    path = Path('.cache/xnu-work/osfmk/vm/vm_user.c')
    if not path.is_file():
        return None
    lines = path.read_text().splitlines(keepends=True)
    hits = [index for index, line in enumerate(lines) if line.strip() == '(void) indices;']
    if not hits:
        return None
    for index in reversed(hits):
        del lines[index]
    path.write_text(''.join(lines))
    return {'vm_user_stray_indices_dropped': len(hits)}


def fix_malformed_pp_expression():
    """The freeze guard in kern_memorystatus_freeze.c reads `#if (... && || ...)`.

    bsd/kern/kern_memorystatus_freeze.c ships a preprocessor expression with the
    watchOS guard chopped out, leaving `XNU_TARGET_OS_IOS && || XNU_TARGET_OS_WATCH`,
    which clang rejects as an invalid token and the file never compiles. Collapse
    the dangling operator.
    """
    fixes = []
    for path in sorted(Path('.cache/xnu-work/bsd').rglob('*.[ch]')):
        source = path.read_text(errors='replace')
        if '&& ||' not in source:
            continue
        patched = source.replace('&& ||', '||')
        if patched != source:
            path.write_text(patched)
            fixes.append(str(path.relative_to('.cache/xnu-work')))
    return {'malformed_pp_expressions': fixes} if fixes else None


if __name__ == '__main__':
    fix_stray_vm_user_indices()
    fix_malformed_pp_expression()
    fix_duplicate_pmap_reserved()
    fix_mockfs_kalloc_type()
    fix_code_signature_entitlements()
    if not DESTINATION.is_dir():
        raise SystemExit('Create the local XNU work source before preparing headers')
    if not CACHE.exists():
        CACHE.parent.mkdir(parents=True, exist_ok=True)
        CACHE.write_bytes(fetch(URL))
    entries = json.loads(CACHE.read_text())
    crypto_cache = CACHE.with_name(f'xnu-driverkit-crypto-{TAG.removeprefix("xnu-")}.json')
    if not crypto_cache.exists():
        crypto_url = URL.replace('/DriverKit?', '/DriverKit/crypto?')
        crypto_cache.write_bytes(fetch(crypto_url))
    for entry in json.loads(crypto_cache.read_text()):
        entry['relative'] = 'crypto/' + entry['name']
        entries.append(entry)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        restored = [entry for entry in executor.map(restore, entries) if entry]
        trust_tag = TRUST_TAG
        trust_cache = CACHE.with_name(f'xnu-trustcache-{TRUST_TAG.removeprefix("xnu-")}.json')
        if not trust_cache.exists():
            url = ('https://api.github.com/repos/apple-oss-distributions/xnu/'
                   f'contents/EXTERNAL_HEADERS/TrustCache?ref={trust_tag}')
            trust_cache.write_bytes(fetch(url))
        trust_destination = Path('.cache/xnu-work/EXTERNAL_HEADERS/TrustCache')
        def restore_trust(entry):
            return restore(entry, trust_destination, trust_tag)
        restored.extend(entry for entry in executor.map(
            restore_trust, json.loads(trust_cache.read_text())) if entry)
    previous = Path('.cache/sources/xnu-restored-headers.json')
    existing = json.loads(previous.read_text()) if previous.exists() else []
    by_name = {entry['name']: entry for entry in existing + restored}
    previous.write_text(json.dumps(list(by_name.values()), indent=2) + '\n')
    print(f'Restored {len(restored)} omitted public headers from Apple; blob hashes verified')
